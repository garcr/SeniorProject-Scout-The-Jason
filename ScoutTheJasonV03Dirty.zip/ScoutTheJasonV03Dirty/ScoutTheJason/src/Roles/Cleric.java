package Roles;

public class Cleric extends BaseRole {
	
    public Cleric()
    {
        super("Cleric", "Remedy", "Heal 50 points of health");
    }

    @Override
    public String action(BaseRole r)
    {
        if(r.getRoleName().equals(super.getRoleName()))
        {
            if(super.getCount() == 0)
            {
                super.updateCount();//uodate count, cleric can only self-heal once
                r.heal(50);
                return "You healed yourself for 50 points, but can't heal yourself again";                
            }
            else
                return "You healed youself once already, can't heal again!";
        }
        else
            r.heal(50);
	return "Your target was healed for 50 points" ;
    }
        
}