package Roles;

public class WitchDoc extends BaseRole {
	
    public WitchDoc()
    {
        super("Witch Doctor", "Bewitch", "Kill/Revive any Player, unless they are Jason");
    }

    @Override
    public String action(BaseRole r)
    {
        if (actionW(r))
        {
            // successfully killed/revived
	    return "Killed/Revived person you targeted";
        }
        else
        {
            // targetted Jason!
	    return "You targeted Jason!";
        }
    }

    public boolean actionW(BaseRole r)
    {
        if (r.getRoleName().equals("Jason"))
        {
            //r.kill(); CANNOT KILL
            return false;
        }
        else
        {
            if (r.isDead())
                r.revive();
            else
                r.kill();
            return true;
        }
    }
	
}