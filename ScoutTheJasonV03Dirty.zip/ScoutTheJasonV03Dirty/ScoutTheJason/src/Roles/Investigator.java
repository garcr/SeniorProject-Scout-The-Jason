package Roles;

public class Investigator extends BaseRole {
	
    public Investigator()
    {
        super("Investigator", "Scope", "Reveal role of another Player");
    }

    @Override
    public String action(BaseRole r)
    {
        // return this somehow
	return "The role of the person you investigated was " + r.getRoleName();  
    }
	
}