package Roles;

public class Warrior extends BaseRole {
	
    public Warrior()
    {
        super("Warrior", "Strike", "Strike another Player for 40 damage");
    }

    @Override
    public String action(BaseRole r)
    {
        r.takeDamage(40);
	return "The person you targeted took 40 points of damage";
    }
	
}