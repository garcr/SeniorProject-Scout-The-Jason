package clientserver;

import java.net.Socket;
import java.util.Scanner;
import java.io.*;

public class EchoClient2 {
    static boolean isDead = false;
    static boolean gameState = true;
    static boolean valid = true;
    
    public static void main(String[] args) throws IOException 
    { 
        MenuDisplayUI menu = new MenuDisplayUI();
        menu.casesDisplay();//run menu b4 game begins

        Socket s = new Socket();		
        DataInputStream dis;
        DataOutputStream dos;
        String server_msg;
        int messageCount = 0;

        Scanner scn = new Scanner(System.in); 
        try
        {
            // establish the connection with server port 9806
            s = new Socket("localhost", 9806);

            dis = new DataInputStream(s.getInputStream()); 

            System.out.println(dis.readUTF()); //first string hello from server
            //speak to server and clients
          //  scn.close();
        }
        catch (Exception e)
        {
            // TODO: Error message
            System.exit(0);
        }

        // obtaining input and out streams 			
        dis = new DataInputStream(s.getInputStream()); 
        dos = new DataOutputStream(s.getOutputStream()); 

        System.out.println("* Waiting for all players to connect . . .");
        
        do
        {
            messageCount = 0;
            
            // Phase 1
            while (messageCount != 5)
            {
                try
                {

                    //System.out.print(dis.readUTF());
                    // Receive messages from server when possible
                    server_msg = dis.readUTF();
                    //validation attemp
                    
                    // Check that server prompted user
                    if (server_msg.equals("input"))
                    {

                       // scn.wait(1, messageCount);
                       // scn = new Scanner(System.in);//create new stream 
                        System.out.print("Enter message 0" + ++messageCount + ": ");
                            server_msg = scn.nextLine(); //Give answer
                            dos.writeUTF(server_msg);
                       /* while(scn.hasNext()) {
                            scn.next();
                        }
                        */
                        //else
                          //  server_msg = scn.nextLine();
                        //scn.close();
                        //scn = new Scanner(System.in);//create new stream 
                        //while(valid){
                          //  if(server_msg.matches("/([a-z]+|[A-Z]+)/s"))
                              //  System.out.println("Invalid input");
                            //else
                                //valid = false;
                       // }
                        
                        //dos.writeUTF(server_msg);
                        
                        
                        
                    }
                    else
                    {
                        System.out.println(server_msg);
                    }
                }
                catch (Exception e)
                {
                    // do nothing
                }
                
            }//end phase 1

            // Action Input
            while (true)
            {
                try
                {
                    server_msg = dis.readUTF();
                        
                    // Check that server prompted user
                    if (server_msg.equals("action"))
                    {
                        System.out.print("> ");

                        server_msg = scn.nextLine(); //Give answer
                        while(valid == true){
                            if(server_msg.matches("(\\D+)") || server_msg.equals("")){//match non-digit 1 or more times
                                System.out.println("Invalid input, please enter a number!\n> ");
                                server_msg = scn.nextLine(); //Give answer
                            }
                            else if(Integer.parseInt(server_msg) < 1 ||Integer.parseInt(server_msg) > 5){
                                System.out.println("Invalid input, number must be between 1 - 5!\n> ");
                                server_msg = scn.nextLine(); //Give answer
                            }else{
                                System.out.println("Valid\n");
                                valid = false;
                                    }
                        }
                        dos.writeUTF(server_msg);
                        break;
                    }
                    else
                    {
                        System.out.println(server_msg);
                    }
                }
                catch (Exception e)
                {
                    // do nothing
                }
            }

            // Action result
            while (true)
            {
                try
                {
                    server_msg = dis.readUTF();

                    // Check that server prompted user
                    if (server_msg.equals("result1"))
                    {
                        break;
                    }
                    else
                    {
                        System.out.println(server_msg);
                    }
                }
                catch (Exception e)
                {
                    // do nothing
                }
            }
            
            // Results Phase
            while (true)
            {
                try
                {
                    server_msg = dis.readUTF();

                    // Check that server prompted user
                    if (server_msg.equals("result2"))
                    {
                        break;
                    }
                    else
                    {
                        System.out.println(server_msg);
                    }
                }
                catch (Exception e)
                {
                    // do nothing
                }
            }
            
            // Game State
            while (true)
            {
                try
                {
                    //System.out.print(dis.readUTF());
                    // Receive messages from server when possible
                    server_msg = dis.readUTF();

                    // Check that server prompted user
                    if (server_msg.equals("end"))
                    {
                        gameState = false;
                        break;
                    }
                    else
                    {
                        System.out.print(server_msg);
                        // move on
                        break;
                    }
                }
                catch (Exception e)
                {
                    // ignore for now
                }
            }
        } while (gameState == true);
    }
}